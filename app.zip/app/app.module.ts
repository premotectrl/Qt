import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {WebSocketManager} from './services/web-socket-manager.service'
import {OperationalDataService} from './services/operational-data.service'
import { Location,LocationStrategy, PathLocationStrategy } from '@angular/common';
import { AppComponent } from './app.component';
import {HttpClient} from '@angular/common/http'
import { HttpClientModule } from '@angular/common/http';
import { GaugesComponent } from './gauges/gauges.component';
import { ReactiveFormsModule } from '@angular/forms';
import { DeviceManagementService } from './services/device-management.service';


@NgModule({
  declarations: [
    AppComponent,
    GaugesComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    ReactiveFormsModule
  ],
  providers: [OperationalDataService,WebSocketManager, 
    HttpClient, DeviceManagementService,
    Location,  {provide: LocationStrategy, useClass: PathLocationStrategy}],
  bootstrap: [AppComponent]
})
export class AppModule { }
