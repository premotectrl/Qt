import { Injectable, OnInit } from '@angular/core';
import {HttpClient, HttpErrorResponse} from '@angular/common/http'
import {Observable} from 'rxjs/Observable'

export interface IResponse{

} 

const getUrlBasePrefix = "https://www-dev.kuka-atx.com/api";
 
@Injectable()
export class DeviceManagementService implements OnInit{
  data:any;
  private getAllUrl:string;
  private siteId:string; // = "OlhNIbEUSUW4hJYPyy24Pg";
  private deviceUrl:string;
  private assetId = "70ce167b-2258-34d1-9498-7f5b59d70a46"; //"980321";

  constructor(private http: HttpClient) {
   // this.getAllUrl = getUrlBasePrefix  +  '/devices/site/' + this.siteId;
    //this.deviceUrl = getUrlBasePrefix  + '/devices/' +  this.assetId;
    //this.deviceUrl = 'devices/' +  this.assetId +'/properties';
  }
 
  ngOnInit(){ 
    
  }
  set siteID(siteId){
    this.siteId = siteId;
  }
  set assetID(assetId){
    this.assetId = assetId;
  }

  getDevice(deviceId){
    this.assetID = deviceId;
    this.deviceUrl = getUrlBasePrefix  + '/devices/' +  this.assetId +'/properties';
    return this.http.get(this.deviceUrl, {withCredentials:true});
  }

  getAllDevices(siteId){
    this.siteID = siteId;
    this.getAllUrl = getUrlBasePrefix  + '/devices/site/' + this.siteId +'/deviceInfo';
    return this.http.get(this.getAllUrl, {withCredentials:true});
  }
}
