import { Component, OnInit , AfterViewInit, ElementRef, Inject,ViewChild} from '@angular/core';
import {TootipServiceService} from '../tootip-service.service';
import {TooltipComponent} from '../tooltip/tooltip.component'

@Component({
  selector: 'tooltip-container',
  styleUrls: ['./tooltip-container.component.css'],
  template: 
  `
    <div class="tooltip-container" [ngStyle]="{'top':position}">
      <tooltip-content
        *ngFor="let tooltip of tooltipService.components"
        [title]="tooltip.title"
        [ref]="tooltip.ref">
      </tooltip-content>
    </div>
  `
})
export class TooltipContainerComponent implements OnInit, AfterViewInit {
 
 position ="";
  pos2 ="";
  tipper:any;

  constructor(private tooltipService: TootipServiceService, private contRef: ElementRef, @Inject('tooltipConfig') private config) { 
    
  }
  
  ngOnInit() {
    let coord = this.config.host.nativeElement.getBoundingClientRect();
    let val= parseInt(this.config.host.nativeElement.getBoundingClientRect()["top"]);
   
    let height = 160;//height of the tip

    this.position = (coord.top - height) +"px";

    console.log('made container',this.position + "  ...  ",coord.top);
   
  }

  ngAfterViewInit(){
    //this.position = coord.y +"px";
   // this.tipper = this.Tipper;
   
  //console.log('..',this.parent.txt);
  }
  
}
