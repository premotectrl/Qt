import { Directive , OnDestroy, Input, Output, HostListener, ElementRef,ViewChild, ComponentRef, ComponentFactoryResolver, ViewContainerRef, Injector, ReflectiveInjector, EventEmitter, AfterViewInit} from '@angular/core';
import {TootipServiceService} from './tootip-service.service';
import{TooltipContainerComponent} from './tooltip-container/tooltip-container.component'
import {AppComponent} from './../app.component'

@Directive({
  selector: '[my_tooltip]'
})
export class TooltipDirectiveDirective implements OnDestroy{
 // @ViewChild('mover') node: ElementRef;
 
  private componentInstance: ComponentRef<TooltipContainerComponent>;

  @Input() tooltipTitle: string;
  @Input() parent:any;
  private id: any;
  tipper:any;
  hold: boolean = true;
  disableOtherDestroy:boolean = false;
  mouseEntered:boolean = false;
  domChanged:boolean = true;

  /*********** directive two********* */
  private changes: MutationObserver;

  @Output() public my_tooltip = new EventEmitter();

  constructor(private tooltipService: TootipServiceService, private element: ElementRef,
    private injector: Injector, 
    private resolver : ComponentFactoryResolver,
    private vcr : ViewContainerRef) { 

      this.changes = new MutationObserver((mutations: MutationRecord[]) => {
        mutations.forEach((mutation: MutationRecord) => {/*this.my_tooltip.emit(mutation); this.draw_Tool_Tip();* this.domChanged =true;*/});
      }
  );

  this.changes.observe(element.nativeElement, {
    attributes: true,
    childList: true,
    characterData: true
  }); 
}
  
  @HostListener('mouseenter')
  onMouseEnter(): void {

    this.draw_Tool_Tip();
    if(this.hold==true){
      
      this.translateTooltip();
    }
  }

  @HostListener('mouseleave')
  onMouseLeave(): void {
   this.destroy();
  }
  @HostListener('window:scroll',[]) 
  scrolling(){
    if(this.disableOtherDestroy && this.mouseEntered){
      this.disableOtherDestroy = false;
    }else if(this.mouseEntered){
      this.destroy();
    }
  }

  draw_Tool_Tip(): void{
    this.mouseEntered = true;
    this.id = Math.random();
   
    this.tooltipService.components.push({ 
      id: this.id, 
      ref: this.element,//.nativeElement,
      title: this.tooltipTitle 
    });

    /****** added*** */
    const injector = ReflectiveInjector.resolveAndCreate([
      {
        provide: 'tooltipConfig',
        useValue: {
          host: this.element
        }
      }
    ]);
    
    const factory = this.resolver.resolveComponentFactory(TooltipContainerComponent);
    this.componentInstance = this.vcr.createComponent(factory,0,injector);
  }  

  ngOnDestroy(): void {
    this.destroy();
  }

  destroy(): void {
    const idx = this.tooltipService.components.findIndex((t) => { 
      return t.id === this.id; 
    });

    this.tooltipService.components.splice(idx, 1);
    this.componentInstance.destroy();
    /*******directive 2 ****** */
    //this.changes.disconnect();
  }

    translateTooltip():void{    
      setInterval(() => {
        this.destroy();
        this.draw_Tool_Tip();
      }, 250); 

    
  }
}