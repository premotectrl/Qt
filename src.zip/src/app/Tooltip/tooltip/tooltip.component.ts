import { Component, OnInit, Input, HostListener, AfterViewInit ,ViewChild} from '@angular/core';
import {TooltipContainerComponent} from '../tooltip-container/tooltip-container.component'

@Component({
  selector: 'tooltip-content',
  templateUrl: './tooltip.component.html',
  styleUrls: ['./tooltip.component.css']
})
export class TooltipComponent implements AfterViewInit, OnInit{
  @Input() title: string;
  @Input() ref: any;
  position: any;
  icn = "../assets/KMP/safe-protected_sm.svg";
  
  ngAfterViewInit(): void {
    // position based on `ref`
    //this.position = this.ref.nativeElement.getBoundingClientRect()["top"];
    //this.ref.nativeElement.style["top"] = (this.position + 60).toString() + "px";
    //console.log(this.position);
  }
  ngOnInit():void{
    //this.position = parseInt(this.ref.nativeElement.getBoundingClientRect()["top"]);
    console.log("tooltip..");
  }

  @HostListener('window:resize')
  onWindowResize(): void {
    // update position based on `ref`
   
  }
}
