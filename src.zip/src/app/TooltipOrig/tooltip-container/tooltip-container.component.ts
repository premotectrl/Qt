import { Component, OnInit , AfterViewInit, ElementRef} from '@angular/core';
import {TootipServiceService} from '../tootip-service.service';
import {TooltipComponent} from '../tooltip/tooltip.component'

@Component({
  selector: 'tooltip-container',
  styleUrls: ['./tooltip-container.component.css'],
  template: 
  `
    <div class="tooltip-container">
      <tooltip-content
        *ngFor="let tooltip of tooltipService.components"
        [title]="tooltip.title"
        [ref]="tooltip.ref">
      </tooltip-content>
    </div>
  `
})
export class TooltipContainerComponent implements OnInit {
  ref:any ="";
  position: any;
  constructor(private tooltipService: TootipServiceService, private contRef: ElementRef) { }

   ngOnInit(){
    this.tooltipService.components.forEach(element => {
      this.ref= element.ref;
    });
    //let v = this.contRef.nativeElement.getBoundingClientRect()["top"];
    //let v = this.ref.nativeElement.getBoundingClientRect()["top"];
    //this.contRef.nativeElement.style["top"] = (v).toString() + "px";
   // let temp =  (v + 500).toString() + "px";
    //console.log("container: ", temp);

    let v = this.ref.nativeElement.getBoundingClientRect()["top"];
    this.contRef.nativeElement.parentElement.style["top"] = "-900px";
   }

  ngAfterViewInit(): void {
    // position based on `ref`
  //this.tooltipService.components.forEach(element => {
      //this.ref= element.ref;
   // });
    //let v = this.contRef.nativeElement.getBoundingClientRect()["top"];
    let v = this.ref.nativeElement.getBoundingClientRect()["top"];
    this.contRef.nativeElement.parentElement.style["top"] = "-800";
  } 

}
