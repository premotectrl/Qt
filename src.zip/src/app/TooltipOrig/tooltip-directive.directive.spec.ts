import { TooltipDirectiveDirective } from './tooltip-directive.directive';

describe('TooltipDirectiveDirective', () => {
  it('should create an instance', () => {
    const directive = new TooltipDirectiveDirective();
    expect(directive).toBeTruthy();
  });
});
