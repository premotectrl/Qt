import { Directive , OnDestroy, Input, HostListener, ElementRef} from '@angular/core';
import {TootipServiceService} from './tootip-service.service';

@Directive({
  selector: '[my-tooltip]'
})
export class TooltipDirectiveDirective implements OnDestroy{

  @Input() tooltipTitle: string;
  private id: any;

  constructor(private tooltipService: TootipServiceService, private element: ElementRef) { }
  
  @HostListener('mouseenter')
  onMouseEnter(): void {
    this.id = Math.random();
    //console.log(this.element.nativeElement);
    this.tooltipService.components.push({ 
      id: this.id, 
      ref: this.element, 
      title: this.tooltipTitle 
    });
  }

  @HostListener('mouseleave')
  onMouseLeave(): void {
    this.destroy();
  }
  
  ngOnDestroy(): void {
    this.destroy();
  }

  destroy(): void {
    const idx = this.tooltipService.components.findIndex((t) => { 
      return t.id === this.id; 
    });

    this.tooltipService.components.splice(idx, 1);
  }
}