import { Component, OnInit, Input, HostListener, AfterViewInit } from '@angular/core';

@Component({
  selector: 'tooltip-content',
  templateUrl: './tooltip.component.html',
  styleUrls: ['./tooltip.component.css']
})
export class TooltipComponent implements OnInit, AfterViewInit{
  @Input() title: string;
  @Input() ref: any;
  position: any = 10;
  ngOnInit(){
    this.position = this.ref.nativeElement.getBoundingClientRect()["top"];
   
  }
  ngAfterViewInit(): void {
    // position based on `ref`
    //this.position = this.ref.nativeElement.getBoundingClientRect()["top"];
    this.ref.nativeElement.style["top"] = (this.position - 60).toString() + "px";
    let tmp =(this.position - 60).toString() + "px";
    console.log(this.ref.nativeElement.parentElement);
  }

  @HostListener('window:resize')
  onWindowResize(): void {
    // update position based on `ref`
   
  }
  public getRef(): any{
    return this.position;
  }


}
