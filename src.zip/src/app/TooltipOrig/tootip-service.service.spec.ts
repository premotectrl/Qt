import { TestBed, inject } from '@angular/core/testing';

import { TootipServiceService } from './tootip-service.service';

describe('TootipServiceService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [TootipServiceService]
    });
  });

  it('should be created', inject([TootipServiceService], (service: TootipServiceService) => {
    expect(service).toBeTruthy();
  }));
});
