import { Component, OnDestroy, Injectable,OnInit, ElementRef,ViewChild, Renderer2, AfterViewInit,ViewContainerRef} from '@angular/core';
import { OperationalDataService } from './services/operational-data.service';
import {FormGroup, FormControl, Validators, FormsModule} from '@angular/forms';
import {GaugesComponent} from './gauges/gauges.component';
import {Observable} from 'rxjs/Observable';
import  'rxjs/add/operator/map'
import { DeviceManagementService } from './services/device-management.service';
import{SafetyStatesComponent} from './safety-states/safety-states.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})

export class AppComponent implements OnInit, AfterViewInit {
  @ViewChild('mover') mover: ElementRef;

  val: any;
  results:Observable<any>;
  results2:Observable<any>;
  outer:any;
  siteAVGs: any;
  explored:any=[];
  assetId: string = "980320";//"8994c3d4-a148-3770-9868-3b4864f97100";//"980321";
  private siteId:string= "OlhNIbEUSUW4hJYPyy24Pg";
  dataIn: any;
  AvgProp: Observable<any>;
 public welcomeTxt: string = `Welcome to party!`;
  welcomeTxt2: string = `Welcome to party 2!`;
  diver: any;
  parent:any;

  push :number = -100;
 
  
  //the data values contained in here are passed to the child component input and in turn the child render
  //its view with these values.. like e.g: @Input() props: { waitFor: boolean; message: string; };
  // and in Parent template use the child ..eg app-root like :<app-State [props]="dashProps"><app-State'
  dashProps ={
    waitFor: true,
    message: "State"
  }
  /***********for charts.. passed down to gauges */
  cLabel=["Balaaa","Tried..", "Born", "Today"];
  dataOut:any=[];
  num: number = 0;

  gaugeConfig={ 
    AVGName: "",
    AVGFleet:"",
    labels:[],
    color: "#f3f1",
    level: [0,100],
    withPointer: true
  }
  /*************************************** */
  safeState = {
    stateText:"safe mode",
    iconPath:"../assets/KMP/connect-not.svg",
    stateCount: 2,
    borderColor: "#1B8642"
  }

  ackState = {
    stateText:"acknowledge",
    iconPath:"../assets/KMP/safe-ack.svg",
    stateCount: 1,
    borderColor: "#9F547D"
  }

  warningState = {
    stateText:"Warning",
    iconPath:"../assets/KMP/safe-warning.svg",
    stateCount: 5,
    borderColor: "#FFCD00"
  }
  errorState = {
    stateText:"E-stop",
    iconPath:"../assets/KMP/safe-estop_sm.svg",
    stateCount: 0,
    borderColor: "#CF2027"
  }
  protectState = {
    stateText:"Protective stop",
    iconPath:"../assets/KMP/safe-protected_sm.svg",
    stateCount: 8,
    borderColor: "#FF5800"
  }
  radioCharts = [this.safeState,this.ackState, this.errorState];

  constructor(private opDataService: OperationalDataService,
              private DeviceManagement: DeviceManagementService, private vcr : ViewContainerRef,
              private renderer : Renderer2 ) {
    /* opDataService.get(this.assetId).subscribe(data=>{ 
      this.dataIn = data;
    });
    this.val = 200;
    console.log(""+this.update()); */

   /* this.AvgProp = DeviceManagement.getDevice(this.assetId);
    this.AvgProp.subscribe((data)=>{
      this.results = data;
      console.log("first: ",this.results)});*/
      
  }
  
  ngOnInit() {
    this.results = this.DeviceManagement.getDevice(this.assetId);
    this.results2 = this.DeviceManagement.getAllDevices(this.siteId);

    let Increment = true;
    setInterval(() => {
      if(this.gaugeConfig.level[0] < 100 && Increment == true){
      this.gaugeConfig.level[0] += 5;}
      else{
       Increment = false;
        this.gaugeConfig.level[0] -= 5;
        if(this.gaugeConfig.level[0] <= 0)
         Increment = true;
      }
      this.gaugeConfig = Object.assign({},this.gaugeConfig);
      this.push += 10
     /*********move the element */
      this.renderer.setStyle(this.mover.nativeElement, 'top', this.push+"px");
      console.log(this.push);
    }, 500); 

    this.results.subscribe(res => {this.outer = res;
      console.log("response...:",res)});
    
      this.results2.subscribe((res) => {this.siteAVGs = res['Devices'];
        console.log("siteAVG...:", this.siteAVGs[0]);
      });
  }

  update(){
    return this.val;
  }
  
  /***********get test data to test liveness of charts */
  miForm = new FormGroup({
    data: new FormControl('',Validators.required),
    txt: new FormControl('')
  });

  useData(miForm){
   // this.dataOut[0] = this.data.value;
    //this.num = this.data.value;
  /*this.results.subscribe(res => {this.outer = res;
  console.log("response...:",res)});

  this.results2.subscribe((res) => {this.siteAVGs = res['Devices'];
    console.log("siteAVG...:", this.siteAVGs[0]);
  }); */
  
  this.explored = this.siteAVGs;
  console.log("explored...:", this.explored[0].Model);
  }

  get data(){
    
    console.log("called get..");
    return this.miForm.get("data");
  }
  get txt(){
    return this.miForm.get("txt");
  }
  ngAfterViewInit(){
  
    //this.renderer.setStyle(this.mover.nativeElement, 'left', this.push+"px");
    //let left_Pos = this.mover.nativeElement.getBoundingClientRect()["left"];
    
   
  }

  onDomChange($event: Event): void {
    console.log($event);
  }
}
