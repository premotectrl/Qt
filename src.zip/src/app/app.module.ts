import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {WebSocketManager} from './services/web-socket-manager.service'
import {OperationalDataService} from './services/operational-data.service'
import { Location,LocationStrategy, PathLocationStrategy } from '@angular/common';
import { AppComponent } from './app.component';
import {HttpClient} from '@angular/common/http'
import { HttpClientModule } from '@angular/common/http';
import { GaugesComponent } from './gauges/gauges.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { DeviceManagementService } from './services/device-management.service';
import {SafetyStatesComponent} from './safety-states/safety-states.component';

import { TooltipComponent } from './Tooltip/tooltip/tooltip.component';
import { TooltipContainerComponent } from './Tooltip/tooltip-container/tooltip-container.component';

import { TootipServiceService} from './Tooltip/tootip-service.service'
/********* new for tooltip***** */

import { SharedModule } from './shared.module';

@NgModule({
  declarations: [
    AppComponent,
    GaugesComponent,
    SafetyStatesComponent,
    TooltipComponent,
    TooltipContainerComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    ReactiveFormsModule,
    SharedModule,
    FormsModule
  ],
  providers: [OperationalDataService,WebSocketManager, 
    HttpClient, DeviceManagementService, TootipServiceService,
    Location,  {provide: LocationStrategy, useClass: PathLocationStrategy}],
  bootstrap: [AppComponent],
  entryComponents:[ TooltipContainerComponent]
})
export class AppModule { }
