import { Component, OnInit, Input,Output, EventEmitter } from '@angular/core';


@Component({
  selector: 'app-safety-states',
  templateUrl: './safety-states.component.html',
  styleUrls: ['./safety-states.component.css']
})
export class SafetyStatesComponent {

  @Input() state = {
    stateText:String,
    iconPath:String,
    stateCount: Number,
    borderColor:String
  }
  constructor() {}
}
 