import { TestBed, inject } from '@angular/core/testing';

import { WebSocketManager } from './web-socket-manager.service';

describe('WebSocketManager', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [WebSocketManager]
    });
  });

  it('should be created', inject([WebSocketManager], (service: WebSocketManager) => {
    expect(service).toBeTruthy();
  }));
});
