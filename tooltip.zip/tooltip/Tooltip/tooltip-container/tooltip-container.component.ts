import { Component, OnInit , AfterViewInit, ElementRef, Inject} from '@angular/core';
import {TootipServiceService} from '../tootip-service.service';
import {TooltipComponent} from '../tooltip/tooltip.component'

@Component({
  selector: 'tooltip-container',
  styleUrls: ['./tooltip-container.component.css'],
  template: 
  `
    <div class="tooltip-container" [ngStyle]="{top: position}">
      <tooltip-content
        *ngFor="let tooltip of tooltipService.components"
        [title]="tooltip.title"
        [ref]="tooltip.ref">
      </tooltip-content>
    </div>
  `
})
export class TooltipContainerComponent implements OnInit {
  position ="-40px";
  constructor(private tooltipService: TootipServiceService, private contRef: ElementRef, @Inject('tooltipConfig') private config) { }
  
  ngOnInit() {
    const {top} = this.config.host.getBoundingClientRect();
    const {height} = this.contRef.nativeElement.getBoundingClientRect();
    //this.position = `${top}px`;
  }
}
