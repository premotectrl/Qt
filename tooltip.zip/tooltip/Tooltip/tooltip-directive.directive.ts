import { Directive , OnDestroy, Input, HostListener, ElementRef, ComponentRef, ComponentFactoryResolver, ViewContainerRef, Injector, ReflectiveInjector} from '@angular/core';
import {TootipServiceService} from './tootip-service.service';
import{TooltipContainerComponent} from './tooltip-container/tooltip-container.component'

@Directive({
  selector: '[my-tooltip]'
})
export class TooltipDirectiveDirective implements OnDestroy{
  private componentInstance: ComponentRef<TooltipContainerComponent>;

  @Input() tooltipTitle: string;
  private id: any;

  constructor(private tooltipService: TootipServiceService, private element: ElementRef,
    private injector: Injector, 
    private resolver : ComponentFactoryResolver,
    private vcr : ViewContainerRef) { }
  
  @HostListener('mouseenter')
  onMouseEnter(): void {
   
    this.id = Math.random();
   
    this.tooltipService.components.push({ 
      id: this.id, 
      ref: this.element, 
      title: this.tooltipTitle 
    });

    /****** added*** */
    const injector = ReflectiveInjector.resolveAndCreate([
      {
        provide: 'tooltipConfig',
        useValue: {
          host: this.element.nativeElement
        }
      }
    ]);

    const factory = this.resolver.resolveComponentFactory(TooltipContainerComponent);
    this.componentInstance = this.vcr.createComponent(factory,0,injector);
  }

  @HostListener('mouseleave')
  onMouseLeave(): void {
    this.destroy();
  }
  
  ngOnDestroy(): void {
    this.destroy();
  }

  destroy(): void {
    const idx = this.tooltipService.components.findIndex((t) => { 
      return t.id === this.id; 
    });

    this.tooltipService.components.splice(idx, 1);
    this.componentInstance.destroy();
  }
}